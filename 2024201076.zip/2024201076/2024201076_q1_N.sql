SELECT city
FROM offices
INTERSECT
SELECT city
FROM customers;